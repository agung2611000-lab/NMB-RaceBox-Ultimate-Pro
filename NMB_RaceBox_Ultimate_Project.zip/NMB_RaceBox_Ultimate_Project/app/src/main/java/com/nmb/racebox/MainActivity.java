package com.nmb.racebox;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.content.Context;

public class MainActivity extends Activity {
    private WebView webView;
    private LocationManager locationManager;
    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            double speed = location.hasSpeed() ? location.getSpeed() * 3.6 : 0;
            double accuracy = location.hasAccuracy() ? location.getAccuracy() : -1;
            final String js = "window.onNativeGps && window.onNativeGps(" + speed + "," + accuracy + "," + location.getLatitude() + "," + location.getLongitude() + ")";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF101318);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void startGps() { runOnUiThread(() -> requestGps()); }
            @JavascriptInterface public void stopGps() { runOnUiThread(() -> stopGpsUpdates()); }
        }, "RaceBoxNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private void requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 51);
            return;
        }
        try {
            locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 250, 0, listener);
        } catch (Exception e) {
            webView.evaluateJavascript("window.onGpsError && window.onGpsError('GPS tidak tersedia atau izin ditolak')", null);
        }
    }
    private void stopGpsUpdates() {
        try { if (locationManager != null) locationManager.removeUpdates(listener); } catch (Exception ignored) {}
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 51 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestGps();
        else webView.evaluateJavascript("window.onGpsError && window.onGpsError('Izin lokasi diperlukan untuk GPS speedometer')", null);
    }
    @Override protected void onDestroy() { stopGpsUpdates(); super.onDestroy(); }
}
