# NMB RaceBox Ultimate — Android project

Aplikasi prototipe Android berbahasa Indonesia untuk:
- GPS speedometer dan peak speed
- estimasi waktu 0–60 dan 0–100 km/jam
- drag timer berbasis jarak GPS (100 m, 201 m, 402 m)
- kalkulator kapasitas mesin (cc)
- kalkulator rasio kompresi statis
- kalkulator kecepatan teoritis berdasarkan RPM, rasio final/total, dan keliling ban
- riwayat lokal di perangkat

## Cara membuat APK
1. Instal Android Studio versi terbaru di komputer.
2. Ekstrak folder project ini.
3. Buka folder `NMB_RaceBox_Ultimate` dari Android Studio.
4. Tunggu Gradle Sync. Jika diminta, instal Android SDK Platform 35 dan Build Tools.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Ini adalah source project, bukan file APK yang sudah dikompilasi.
- Proyek membutuhkan Android SDK dan Gradle yang sesuai untuk menghasilkan APK; lingkungan pembuatan saat ini tidak memiliki toolchain Android lengkap.
- Untuk kalkulator gear, isi nilai rasio total yang sesuai untuk gear yang sedang diuji. Rumus kecepatan teoritis mengasumsikan nilai itu adalah rasio primer × rasio gear × rasio final, sedangkan rasio final dihitung dari jumlah gigi belakang/depan. Sesuaikan sesuai cara data rasio yang dimasukkan agar tidak menghitung rasio final dua kali.
- GPS HP memiliki batas akurasi dan latensi; hasil 0–60, 0–100, dan drag bersifat perkiraan. Untuk pengukuran motorsport presisi, gunakan perangkat GNSS eksternal yang sesuai.
- Jangan menguji di jalan umum. Gunakan lintasan tertutup dan jangan mengoperasikan HP ketika berkendara.
